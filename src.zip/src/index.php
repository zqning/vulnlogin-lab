<?php
// ==========================================
// 漏洞 2.1：明文传输 - 后端返回密码到前端
// 危害：攻击者抓包可直接看到所有用户的密码
// ==========================================

// 模拟数据库 - 用户表
$users = [
    'admin' => 'Admin@2024!',
    'user'  => 'User#1234',
    'test'  => 'TestP@ss1',
];

$response = [
    'success' => false,
    'message' => '',
    'password' => null,   // 漏洞点：返回明文密码
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 接收前端 JSON 数据
    $input = json_decode(file_get_contents('php://input'), true);
    $username = $input['username'] ?? '';
    $password_input = $input['password'] ?? '';

    if (isset($users[$username])) {
        // 漏洞核心：把正确密码通过 JSON 返回给前端
        // 前端会用它和用户输入的密码做比对
        $response['password'] = $users[$username];

        if ($password_input === $users[$username]) {
            $response['success'] = true;
            $response['message'] = "✅ 登录成功！欢迎回来，{$username}。";
        } else {
            $response['message'] = "❌ 密码错误，请重试。";
        }
    } else {
        $response['message'] = "❌ 用户不存在。";
    }

    // 返回 JSON 响应（包含明文密码）
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2.1 明文传输漏洞 | VulnLogin-Lab</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text: #1e293b;
            --muted: #64748b;
            --border: #e2e8f0;
            --danger: #ef4444;
            --danger-bg: #fef2f2;
            --warning: #f59e0b;
            --warning-bg: #fffbeb;
            --success: #10b981;
            --success-bg: #ecfdf5;
            --primary: #3b82f6;
            --primary-hover: #2563eb;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }
        .nav {
            background: #1e293b;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .nav a {
            color: #e2e8f0;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }
        .nav a:hover { color: #38bdf8; }
        .nav .sep { color: #475569; }
        .container {
            max-width: 520px;
            margin: 2.5rem auto;
            padding: 0 1rem;
        }
        .card {
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
            padding: 2rem;
            border: 1px solid var(--border);
        }
        .card h1 {
            font-size: 1.5rem;
            margin-bottom: 0.25rem;
        }
        .card .subtitle {
            font-size: 0.85rem;
            color: var(--muted);
            margin-bottom: 1.5rem;
        }
        .alert {
            padding: 0.75rem 1rem;
            border-radius: 6px;
            font-size: 0.85rem;
            margin-bottom: 1.25rem;
            line-height: 1.5;
        }
        .alert-warning {
            background: var(--warning-bg);
            border: 1px solid var(--warning);
            color: #92400e;
        }
        .form-group { margin-bottom: 1rem; }
        .form-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }
        .form-group input {
            width: 100%;
            padding: 0.65rem 0.85rem;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.2s;
            outline: none;
        }
        .form-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(59,130,246,0.1); }
        .btn {
            width: 100%;
            padding: 0.7rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn:hover { background: var(--primary-hover); }
        .btn:active { transform: scale(0.98); }
        .result {
            margin-top: 1rem;
            padding: 0.75rem 1rem;
            border-radius: 6px;
            font-size: 0.9rem;
            display: none;
            line-height: 1.6;
        }
        .result.show { display: block; }
        .result-success {
            background: var(--success-bg);
            border: 1px solid var(--success);
            color: #065f46;
        }
        .result-error {
            background: var(--danger-bg);
            border: 1px solid var(--danger);
            color: #991b1b;
        }
        .leak-box {
            margin-top: 1rem;
            padding: 1rem;
            background: var(--danger-bg);
            border: 1px solid var(--danger);
            border-radius: 6px;
            display: none;
            line-height: 1.7;
        }
        .leak-box.show { display: block; }
        .leak-box .label {
            font-size: 0.8rem;
            font-weight: 700;
            color: var(--danger);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .leak-box code {
            background: #fee2e2;
            padding: 0.15rem 0.4rem;
            border-radius: 3px;
            font-family: 'Fira Code', monospace;
            font-size: 0.9rem;
            color: #991b1b;
        }
        .tip {
            margin-top: 1.5rem;
            font-size: 0.8rem;
            color: var(--muted);
            border-top: 1px solid var(--border);
            padding-top: 1rem;
        }
        .tip strong { color: var(--text); }
    </style>
</head>
<body>
    <!-- 导航 -->
    <nav class="nav">
        <a href="/">🏠 首页</a>
        <span class="sep">/</span>
        <span style="color:#38bdf8;">2.1 明文传输</span>
    </nav>

    <div class="container">
        <div class="card">
            <h1>🔐 明文传输漏洞</h1>
            <p class="subtitle">后端在 API 响应中直接返回用户密码</p>

            <div class="alert alert-warning">
                💡 <strong>测试提示：</strong>输入用户名 <code>admin</code>，随便填个错误密码，然后打开浏览器 <strong>F12 → Network</strong> 查看 API 响应。
            </div>

            <form id="loginForm">
                <div class="form-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" name="username" placeholder="输入用户名，如 admin" required autocomplete="off">
                </div>
                <div class="form-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" name="password" placeholder="输入任意密码" required autocomplete="off">
                </div>
                <button type="submit" class="btn">登 录</button>
            </form>

            <!-- 登录结果 -->
            <div id="loginResult" class="result"></div>

            <!-- 密码泄露展示框 -->
            <div id="leakBox" class="leak-box">
                <span class="label">⚠️ 漏洞触发！API 响应泄露了明文密码</span><br><br>
                用户名：<code id="leakUser"></code><br>
                正确密码：<code id="leakPass"></code><br><br>
                <small style="color:#991b1b;">
                    攻击者现在可以用 <code id="leakCred"></code> 直接登录！
                </small>
            </div>

            <div class="tip">
                <strong>🛡️ 修复建议：</strong>永远不要在 API 响应中返回密码。密码验证必须<strong>完全在后端</strong>完成，前端只接收成功/失败状态。
            </div>
        </div>
    </div>

    <!-- 引入前端登录脚本 -->
    <script src="login.js"></script>
</body>
</html>